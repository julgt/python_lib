__author__ = "Gustavo Niemeyer"
__copyright__ = "Copyright (c) 2005-2018 - Gustavo Niemeyer <gustavo@niemeyer.net>"
__credits__ = ["Sebastien Celles"]
__license__ = ""
__version__ = "1.4.0"
__email__ = "gustavo@niemeyer.net"
__status__ = "Development"
__url__ = "https://github.com/python-constraint/python-constraint"
