import sys

import pytest

def func(x):
    return x + 1
@pytest.mark.parametrize(
    ('name'),[
        (1),
        (2),
        (3)
    ]
)
class TestClass:
    def test_answer(self,name):
        assert func(name) == 4

    @pytest.mark.skipif(
        sys.platform == 'windows',
        reason=" ла-ла-ала"
    )
    def test_answer2(self,name):
        print("profile -------------- "+ str(sys.getprofile()))
        assert func(name) == 3


