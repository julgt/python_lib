import requests
from configuration import SERVICE_URL
from src.schemas.post import POST_SCHEMA
from pydantic_schemas.post_pydant import Post
from jsonschema import validate
from src.enums.global_enums import GlobalEnumsMessages

from src.baseclasses.response import Response


def test_getting_posts_pydanticschema():
    r = requests.get(url=SERVICE_URL)
    response = Response(r)
    response.assert_status_code(200).validate2(Post)

def test_getting_posts_jsonschema():
    r = requests.get(url=SERVICE_URL)
    response = Response(r)

    response.assert_status_code(200).validate(POST_SCHEMA)

    # received_posts = response.json()
    # print(received_posts)
    # assert response.status_code == 200, GlobalEnumsMessages.WRONG_STATUS_CODE
    # assert len(received_posts) == 3, GlobalEnumsMessages.WRONG_ELEMENT_COUNT
    # for item in received_posts:
    #     validate(item,POST_SCHEMA)

    # [{'id': 1, 'title': 'Post 1'}, {'id': 2, 'title': 'Post 2'}, {'id': 3, 'title': 'Post 3'}]
