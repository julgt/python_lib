import pytest

# использует conftest.py

def test_multiplication(test_input, expected_result):
    assert test_input * 2 == expected_result