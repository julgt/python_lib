from pydantic import BaseModel, validators, Field

class Post(BaseModel):
    id: int = Field(le=10)
    title: str

    # @validators("id")
    # def check_id_less_than_two(cls,v):
    #     if v > 2:
    #         raise ValueError('error!!!')
    #     else:
    #         return v

