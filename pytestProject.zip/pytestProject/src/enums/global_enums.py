from enum import Enum

class GlobalEnumsMessages(Enum):
    WRONG_STATUS_CODE = "Received status code is not equal"
    WRONG_ELEMENT_COUNT = "Число элементов не равно ожидаемому"